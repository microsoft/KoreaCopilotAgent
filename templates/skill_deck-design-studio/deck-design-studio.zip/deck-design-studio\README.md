# Deck Design Studio — 사용 안내

Copilot Cowork로 발표 덱을 만들 때, **서로 완전히 다른 20가지 디자인 중 하나를 골라** 타이틀(표지)부터
본문까지 그 스타일로 일관되게 만드는 스킬입니다. 같은 내용이라도 **디자인 번호만 바꾸면 완전히 다른 룩**이
나옵니다.

---

## 1. 설치 (처음 한 번만)

이 폴더(`deck-design-studio`)를 통째로 본인 OneDrive의 아래 위치에 넣어주세요.

```
OneDrive / 문서 / Coworker / skills / deck-design-studio /
```

- 폴더 안의 `SKILL.md`, `designs/`는 **그대로** 두시면 됩니다 (따로 등록할 필요 없음).
- Cowork의 **Skills(스킬) 목록**에 `deck-design-studio`가 보이면 준비 완료!

---

## 2. 사용법 — 3단계

1. 인덱스/카탈로그에서 마음에 드는 design 번호를 고릅니다 (예: 03 Glass Panels).
2. Cowork에 한 줄로 요청합니다.
   > "design 03으로 8장짜리 발표 덱 만들어줘. 제목은 'AI 워크플로우', 발표자는 OOO."
3. 타이틀부터 본문까지 그 디자인으로 생성됩니다. 어색한 곳만 한 번 더 다듬으면 끝.

폰트는 지정하면 그대로, 안 하면 맑은 고딕으로 나옵니다.

---

## 3. 기억할 점

| | 내용 |
|---|---|
| 🎨 디자인 선택 | design 번호만 바꾸면 같은 내용도 완전히 다른 룩 |
| 🧩 일관성 | 각 디자인의 색·폰트·레이아웃이 고정되어 결과가 흔들리지 않음 |
| 🛠️ 커스터마이즈 | "우리 회사 톤으로 바꿔줘"라고 하면 본인 브랜드에 맞게 수정 가능 |
| 🔁 재사용 | 한 번 설치하면 계속 사용 |

---

## 4. 디자인 20종

| # | 스타일 | # | 스타일 |
|--|--------|--|--------|
| 01 | Dark Keynote | 11 | Fluent 2 |
| 02 | Carbon Grid | 12 | Spectrum Mesh |
| 03 | Glass Panels | 13 | Data Dashboard |
| 04 | Aurora Gradient | 14 | Swiss Tech |
| 05 | Particle Constellation | 15 | Mono-hue Blue |
| 06 | Teal Systems | 16 | Executive Minimal |
| 07 | Neon Streams | 17 | Isometric Blocks |
| 08 | Rose Quartz | 18 | Split-Feature |
| 09 | Orbit Rings | 19 | Gradient Duotone |
| 10 | Graphite | 20 | Editorial Tech |

**고르기 막막할 땐:** 사내·업무 `11 Fluent 2 · 13 Dashboard` / 키노트 `01 Dark Keynote · 04 Aurora` /
데이터 `02 Carbon · 05 Particle` / 임원 `16 Executive · 20 Editorial` / 프리미엄 `03 Glass · 08 Rose · 19 Duotone`

---

## 5. 폴더 구성

```
deck-design-studio/
├── SKILL.md      ← 스킬 본체 (디자인 철학 + 20 인덱스 + GPT-5.5 운영 규칙)
├── designs/      ← 20개 디자인 정의 (자동 참조)
└── README.md     ← 이 안내문
```
